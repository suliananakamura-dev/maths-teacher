# Marvelous Multiplier PWA (GitHub Pages)

1) Create a new public GitHub repo.
2) Upload these files to the repo root.
3) Settings → Pages → Deploy from a branch → `/ (root)` folder.
4) Open the Pages link to install.
